import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/momo_qr_response_model.dart';

class MomoRemoteDataSource {
  final http.Client client;

  MomoRemoteDataSource({required this.client});

  Future<MomoQrResponse> createQrPayment({
    required String orderId,
    required int amount,
    required String orderInfo,
  }) async {
    // TODO: nếu bạn có ApiConstants.baseUrl thì thay vào cho gọn
    final url = Uri.parse('http://10.0.2.2:3000/api/momo/qr');

    final res = await client.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'orderId': orderId,
        'amount': amount,
        'orderInfo': orderInfo,
      }),
    );

    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      return MomoQrResponse.fromJson(data);
    } else {
      throw Exception(
        'Lỗi tạo QR MoMo: ${res.statusCode} ${res.body}',
      );
    }
  }

// Nếu sau này bạn làm check trạng thái đơn hàng thì add thêm hàm ở đây
}
