class MomoQrResponse {
  final String orderId;
  final String qrCodeUrl;
  final String? deeplink;

  MomoQrResponse({
    required this.orderId,
    required this.qrCodeUrl,
    this.deeplink,
  });

  factory MomoQrResponse.fromJson(Map<String, dynamic> json) {
    return MomoQrResponse(
      orderId: json['orderId'] as String? ?? '',
      qrCodeUrl: json['qrCodeUrl'] as String? ?? '',
      deeplink: json['deeplink'] as String?,
    );
  }
}
