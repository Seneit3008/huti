import '../../data/models/momo_qr_response_model.dart';
import '../repositories/momo_payment_repository.dart';

class CreateMomoQrPaymentUseCase {
  final MomoPaymentRepository repo;

  CreateMomoQrPaymentUseCase(this.repo);

  Future<MomoQrResponse> call({
    required String orderId,
    required int amount,
    required String orderInfo,
  }) {
    return repo.createQrPayment(
      orderId: orderId,
      amount: amount,
      orderInfo: orderInfo,
    );
  }
}
