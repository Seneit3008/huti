// lib/features/momo_payment/presentation/bloc/momo_payment_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/usecases/create_momo_qr_payment_uc.dart';
import 'momo_payment_event.dart';
import 'momo_payment_state.dart';

class MomoPaymentBloc extends Bloc<MomoPaymentEvent, MomoPaymentState> {
  final CreateMomoQrPaymentUC createMomoQrPayment;

  MomoPaymentBloc({
    required this.createMomoQrPayment,
  }) : super(const MomoPaymentInitial()) {
    on<CreateMomoQrPaymentEvent>(_onCreateQrPayment);
  }

  Future<void> _onCreateQrPayment(
      CreateMomoQrPaymentEvent event,
      Emitter<MomoPaymentState> emit,
      ) async {
    try {
      emit(const MomoPaymentLoading());

      final res = await createMomoQrPayment(
        orderId: event.orderId,
        amount: event.amount,
        orderInfo: event.orderInfo,
      );

      emit(MomoPaymentSuccess(res)); // 👈 success chứa response
    } catch (e) {
      emit(MomoPaymentFailure(e.toString()));
    }
  }
}
