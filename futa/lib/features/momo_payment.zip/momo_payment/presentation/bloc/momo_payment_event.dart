// lib/features/momo_payment/presentation/bloc/momo_payment_event.dart

abstract class MomoPaymentEvent {}

/// Event gọi API tạo mã thanh toán MoMo QR
class CreateMomoQrPaymentEvent extends MomoPaymentEvent {
  final String orderId;
  final int amount;
  final String orderInfo;

  CreateMomoQrPaymentEvent({
    required this.orderId,
    required this.amount,
    required this.orderInfo,
  });
}
