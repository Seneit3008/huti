// lib/features/momo_payment/presentation/bloc/momo_payment_state.dart
import 'package:equatable/equatable.dart';
import '../../data/models/momo_qr_response_model.dart';

abstract class MomoPaymentState extends Equatable {
  const MomoPaymentState();

  @override
  List<Object?> get props => [];
}

class MomoPaymentInitial extends MomoPaymentState {
  const MomoPaymentInitial();
}

class MomoPaymentLoading extends MomoPaymentState {
  const MomoPaymentLoading();
}

class MomoPaymentSuccess extends MomoPaymentState {
  final MomoQrResponse response; // 👈 model trả về từ API

  const MomoPaymentSuccess(this.response);

  @override
  List<Object?> get props => [response];
}

class MomoPaymentFailure extends MomoPaymentState {
  final String message;

  const MomoPaymentFailure(this.message);

  @override
  List<Object?> get props => [message];
}
