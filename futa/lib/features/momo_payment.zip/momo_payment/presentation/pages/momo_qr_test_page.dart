// lib/features/momo_payment/presentation/pages/momo_qr_test_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../bloc/momo_payment_bloc.dart';
import '../bloc/momo_payment_event.dart';
import '../bloc/momo_payment_state.dart';

class MomoQrTestPage extends StatefulWidget {
  const MomoQrTestPage({super.key});

  @override
  State<MomoQrTestPage> createState() => _MomoQrTestPageState();
}

class _MomoQrTestPageState extends State<MomoQrTestPage> {
  final _orderIdController = TextEditingController(text: '281213');
  final _amountController = TextEditingController(text: '100000');
  final _infoController =
  TextEditingController(text: 'Thanh toán test MoMo QR');

  @override
  void dispose() {
    _orderIdController.dispose();
    _amountController.dispose();
    _infoController.dispose();
    super.dispose();
  }

  void _createQr() {
    final orderId = _orderIdController.text.trim();
    final amount = int.tryParse(_amountController.text.trim()) ?? 0;
    final info = _infoController.text.trim();

    if (orderId.isEmpty || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nhập orderId và amount hợp lệ')),
      );
      return;
    }

    // ⚠️ orderInfo trong event nên là String (không nullable)
    context.read<MomoPaymentBloc>().add(
      CreateMomoQrPaymentEvent(
        orderId: orderId,
        amount: amount,
        orderInfo: info.isEmpty ? 'Thanh toán đơn $orderId' : info,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TEST QR MoMo'),
      ),
      body: BlocBuilder<MomoPaymentBloc, MomoPaymentState>(
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Thông tin test',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                TextField(
                  controller: _orderIdController,
                  decoration: const InputDecoration(
                    labelText: 'Order ID',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),

                TextField(
                  controller: _amountController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Số tiền (VNĐ)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 8),

                TextField(
                  controller: _infoController,
                  decoration: const InputDecoration(
                    labelText: 'Order info (tuỳ chọn)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                ElevatedButton(
                  onPressed: state is MomoPaymentLoading ? null : _createQr,
                  child: state is MomoPaymentLoading
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                      : const Text('TẠO MÃ QR TEST'),
                ),

                const SizedBox(height: 24),

                // --- Khu vực hiển thị kết quả ---
                if (state is MomoPaymentFailure) ...[
                  const Text(
                    'Lỗi:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(state.message),
                ] else if (state is MomoPaymentSuccess) ...[
                  const Text(
                    'QR nhận được từ backend:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),

                  Builder(
                    builder: (context) {
                      // chỉnh field này đúng với model của bạn:
                      // vd: state.response.payUrl, state.response.qrData, ...
                      final qrData = state.response.payUrl ?? '';

                      if (qrData.isEmpty) {
                        return const Text(
                          'Không có dữ liệu QR (payUrl rỗng)',
                          style: TextStyle(color: Colors.red),
                        );
                      }

                      return Column(
                        children: [
                          QrImageView(
                            data: qrData,
                            version: QrVersions.auto,
                            size: 260,
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'Mở app MoMo → Quét mã QR này để test thanh toán.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 12),
                          SelectableText(
                            qrData,
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      );
                    },
                  ),
                ] else ...[
                  const Text(
                    'Nhập thông tin rồi bấm "TẠO MÃ QR TEST".',
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}
